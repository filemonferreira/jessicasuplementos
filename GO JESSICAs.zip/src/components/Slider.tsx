import { Carousel } from "flowbite-react";
import slider1 from '../assets/slider-1.jpg'

export function Slider() {
    return (
        <div className="bg-orange-500 h-96 sm:h-64 xl:h-80 2xl:h-[550px] w-300">
            <Carousel>
                <img
                    src={"https://www.sliderrevolution.com/wp-content/uploads/2021/07/generator.jpg"}
                    alt="..."
                    className="object-contain"
                />
                <img
                    src="https://lojamaxtitanium.vtexassets.com/assets/vtex.file-manager-graphql/images/2a2a2753-0f38-46be-abaa-035bd5183ec9___94358edf9d6e5aebb9f3e1e1ca4b8fc2.jpg"
                    alt="..."
                />
                <img
                    src="https://images.tcdn.com.br/img/img_prod/672331/1646603690_banner_integralmedica.png"
                    alt="..."
                />
                <img
                    src="https://shopfitsuplementos.com/wp-content/uploads/2021/12/1-banINTEGRAL_creatine%20(1).jpg"
                    alt="..."
                />
                <img
                    src="https://integralmedica.vteximg.com.br/arquivos/ids/163669/whey-protein-banner-integralmedica-2.jpg?v=637825407035100000"
                    alt="..."
                />
            </Carousel>
        </div>
    )
}