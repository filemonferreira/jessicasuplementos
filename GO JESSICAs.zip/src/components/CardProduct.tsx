export function CardProduct() {
    return (
        <div className="m-2 w-full md:w-72 bg-white drop-shadow-md rounded-lg">
            <img className="object-cover rounded-tl-lg rounded-tr-lg"
                src="https://images.tcdn.com.br/img/img_prod/461120/creatina_300g_synthesize_8671_1_20200417133638.jpg" />
            <div className="px-5 py-3 space-y-2">
                <h3 className="text-lg">promoção de Creatina synthesize 300g</h3>
                <div className="space-x-2">
                    <span className="px-3 py-0.5 border border-blue-500 text-[11px] text-blue-500">Creatina</span>
                    <span className="px-3 py-0.5 border border-blue-500 text-[11px] text-blue-500">Promoção</span>
                </div>
                <p className="space-x-2">
                    <span className="text-2xl font-semibold">R$ 119.00</span>
                    <span className="text-sm line-through text-gray-500">R$ 139,00</span>
                    <span className="text-sm text-red-700">40% off</span>
                </p>
                <div className="flex justify-between items-center pt-3 pb-2">
                    <a href="#"
                        className="px-4 py-2 bg-red-600 hover:bg-amber-600 text-center text-sm text-white rounded duration-300">
                        Adicionar Carrinho
                    </a>

                    <a href="#" title="Add to Favorites"
                        className="text-2xl text-gray-300 hover:text-red-500 duration-300">&hearts;
                    </a>
                </div>
            </div>
        </div>
    )
}