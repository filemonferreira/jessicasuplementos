export interface GetClientTypeResponse {
    clientTypes: {
        id: string;
        type: string
    }[]
}