import { Outlet } from "react-router-dom";
import { Nav } from "../components/Nav";

export function DefaultLayout() {
    return (
        <div>
            <Nav />
            <Outlet />
            <footer className="w-full bg-gray-700 text-gray-100 p-4 text-center"><h1>Footer</h1></footer>
        </div>
    )
}