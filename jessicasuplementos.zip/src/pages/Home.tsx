import { AiOutlineCheck } from "react-icons/ai";
import { FcApproval, FcCheckmark } from "react-icons/fc";
import { Link } from "react-router-dom";

export function Home() {
    return (
        <>
            <div className="flex p-4 w-full bg-orange-500 border shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700 items-center justify-center">
                <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <strong className="text-gray-100 text-5xl">Nosso compromisso é com seu resultado</strong>
                    <p className="text-gray-600 leading-relaxed mb-6 text-2xl">Para você melhorar sua performace com os melhores suplementos</p>
                    <Link to="/" className="bg-gray-700 text-gray-100 rounded-lg p-4 text-center w-[320px] text-2xl hover:bg-gray-500">Criar conta</Link>
                </div>
                <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 ">
                    <img className="object-fill w-80 bg-cover hidden md:block" src="./src/assets/logo.png" />
                </div>
            </div>
            <header className="bg-white shadow">
                <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <h1 className="text-3xl font-bold text-gray-900">Jessica suplementos</h1>
                </div>
            </header>
            <main>
                <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
                    {/* <!-- Replace with your content --> */}
                    <div className="px-4 py-6 sm:px-0">



                    <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-full">
  <div className="md:flex">
    <div className="md:shrink-0">
      <img className="h-48 w-full object-contain md:h-full md:w-48" src="https://images.tcdn.com.br/img/img_prod/964903/kit_whey_100_creatina_fireblack_53_1_3f348484249ef694440455a07c9b414a.png" alt="Man looking at item at a store" />
    </div>
    <div className="p-8">
      <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold">Kit suplemento</div>
      <a href="#" className="block mt-1 text-lg leading-tight font-medium text-black hover:underline">Cadastre-se e participe do sorteio kit suplementação</a>
      <p className="mt-2 text-slate-500 ">Que tal ganhar um kit suplementação completa só a <span className="text-orange-500">jessica suplementos</span> Sorteia um kit suplemento todo mês contendo.</p>
      
      <ul className="pt-4 mb-6">
        <li className="">01 CREATINA</li>
        <li className="">01 WHEY PROTEIN</li>
        <li className="">01 BCAA</li>
        <li className="">01 COQUETELEIRA</li>
      </ul>
      <Link to="" className="mt-4 p-2 bg-orange-500 rounded-md text-gray-100 hover:bg-orange-400 transition-colors">Participar</Link>
    </div>
  </div>
</div>




                        <h1 className="font-extrabold my-4 text-gray-700 text-2xl">Regras do sorteio</h1>
                        <ul>
                            <li className="flex bg-white text-gray-700 p-2 items-center rounded mb-1 uppercase shadow-md"><FcApproval size={24} /> <strong className="pl-2">Estar Cadastrado no site</strong></li>
                            <li className="flex bg-white text-gray-700 p-2 items-center rounded mb-1 uppercase shadow-md"><FcApproval size={24} /> <strong className="pl-2">Estar Seguindo o instagram</strong></li>
                            <li className="flex bg-white text-gray-700 p-2 items-center rounded mb-1 uppercase shadow-md"><FcApproval size={24} /> <strong className="pl-2">Ter 1 compra ativa na loja</strong></li>
                            <li className="flex bg-white text-gray-700 p-2 items-center rounded mb-1 uppercase shadow-md"><FcApproval size={24} /> <strong className="pl-2">Compartilhar foto Oficial do instagram</strong></li>

                        </ul>
                    </div>
                    {/* <!-- /End replace --> */}
                </div>
            </main>
        </>
    )
}